/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

/**
 *
 * @author azurwular
 */
public class ProductPart
{
    private int id;
    private ProductPartType type;
    private String name;
    private String description;
    private int stock;
    private StockUnit stockUnit;
    private long price;
    private Integer length;
}