/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Web.DTO;

/**
 *
 * @author azurwular
 */
public final class SessionKeys
{
    public static final String user = "CurrentUser";
}
